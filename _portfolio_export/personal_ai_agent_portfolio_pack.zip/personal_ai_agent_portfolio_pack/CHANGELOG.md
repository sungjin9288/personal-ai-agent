# Changelog

All notable public-facing changes are tracked here. This project follows an evidence-first release style: changelog entries should describe verified repository state, not aspirational claims.

## Unreleased

- Aligned portfolio case study, project card, interview story, and resume bullets with completed mission/provider/action operator surface browser evidence.
- Replaced stale future screenshot wording with scoped references to `evidence/screenshots/operator-surface-*.png`, `evidence/output-artifacts/operator-surface-demo-browser-report.json`, and the remaining non-public-demo gaps.
- Added a recorded walkthrough script and smoke guard so future private/public demo video URLs can be added only after evidence, hygiene, and access checks pass.
- Added an architecture code walkthrough and symbol smoke guard so reviewers can navigate CLI/web, mission service, runtime harness, provider registry, local store, and evidence scripts from verified source paths.
- Added a provider readiness matrix and catalog smoke guard to separate adapter implementation, pilot evidence, target provider blockers, and safe multi-provider claims.
- Added a provider failure recovery demo and smoke guard to document attention remediation, fallback policy, timeline/event audit, and claim boundaries.
- Added a memory retrieval quality fixture and smoke guard to document retrieval ranking signals, source diversity, fact graph provenance, revision lifecycle, and instruction-boundary handling.
- Added a credential-free answer quality evaluator and regression fixture for retrieval hit, citation grounding, required content, irrelevant source, and reviewer verdict checks.
- Added a deterministic RAG corpus contract for memory, attachment, and fact source revision, chunk identity, content hash, scope, and provenance without changing serialized retrieval payloads.
- Added a credential-free retrieval evaluation gate for controlled precision, recall, noise, source diversity, and frozen lexical/BM25/phrase baseline comparison.
- Added a bounded local-command embedding protocol and scope-locked semantic retrieval experiment without enabling the mission runtime path.
- Added a deterministic semantic-plus-lexical reranking experiment with controlled tie quality comparison, measured local latency, and state-free baseline rollback without enabling the mission runtime path.
- Added an explicit local semantic-and-lexical mission retrieval runtime with exact lexical default parity, scope refusal, failure-before-provider behavior, and state-free configuration rollback without claiming real embedding model validation.
- Added loopback-only Ollama embedding qualification for installed qwen2.5 0.5B, 1.5B, and 3B models, recording the 3B controlled-suite quality pass while keeping activation blocked on license, egress, resource, and rollback-owner governance.
- Added a 15-case local retrieval robustness evaluation for the selected qwen2.5 3B candidate, recording hard-negative and query-variation regression and enforcing failed-keep-lexical without weakening thresholds or authorizing activation.
- Added an independent local relevance reranker evaluation using repeated structured qwen2.5 3B scoring, recording a controlled 15-case quality pass while keeping runtime activation and governance approval blocked.
- Added a local reranker resource envelope using a preflight-checked lexical top-2 shortlist, recording R8 quality parity, lower inference count and p50/p95/total latency, the loaded-model footprint, and the observed maximum-latency regression while keeping runtime activation blocked.
- Added a bounded local reranker runtime stability evaluation covering confirmed Ollama-model-absent cold state, three warm runs, and two concurrent client workers with 360 inference quality/resource parity while leaving OS cold boot, production parallelism, long-duration soak, thermal behavior, and runtime activation unproven.
- Connected the R10-bound scorer to one controlled four-role stub mission as an observation-only shadow path while preserving lexical provider input, store shape, artifacts, public contracts, and fail-open behavior.
- Replayed 3 controlled scenarios, 15 stub missions, and 60 role observations; retained the full-query 12/15 hard-negative failure as evidence, corrected the scorer query to the qualified mission-objective contract, and passed 15/15 without enabling provider input or production claims.
- Added a content-free 64-entry process-local shadow score cache with exact model, prompt, query, and document binding; the controlled replay retained 15/15 while reducing 120 score requests to 30 model inferences with 90 hits, and disclosed the observed maximum-latency regression without enabling provider input.
- Added generation-based invalidation and rollback close to the shadow score cache; an 8-entry actual replay retained 15/15 with 22 LRU evictions, while a concurrent local probe dropped a pre-invalidation stale result and closed with zero entries without enabling provider input.
- Added bounded child-process cache isolation evidence; two concurrent workers and one restarted worker each began with an empty cache, performed one local inference and one process-local hit, inherited no parent environment, and closed with zero entries without enabling provider input.
- Added forced-termination recovery and bounded cache soak evidence; a warm child exited by SIGKILL, a recovery child inferred again from an empty cache, and a 16-entry cache processed 48 unique pairs plus 16 hits within recorded heap/RSS regression limits without enabling provider input.
- Added an approved learning RAG feedback evaluation; one mission-scoped promotion changed the next retrieval, planner, and deliverable with reviewer pass preserved, then rollback removed the memory and restored exact baseline planner and deliverable hashes without external provider calls.
- Expanded approved learning feedback evaluation to three same-workspace missions and nine stub sessions; the controlled Q1 gate changed from 0/3 before promotion to 3/3 after promotion and returned to 0/3 after rollback, while every case excluded two foreign mission memories and preserved reviewer pass without external provider calls.
- Added explicit mission-to-workspace learning authorization and a controlled workspace-personalization replay; one sibling mission applied the approved decision, a foreign workspace retained zero exposure, timeline audit order was preserved, and rollback restored exact baseline artifacts without external provider calls.
- Added deterministic latest-revision selection for conflicting retrieval-selected workspace decisions; an eight-session local replay verified newer-only provider exposure, exact older fallback after revocation, exact baseline restoration after full rollback, foreign-workspace isolation, and content-free selection evidence without external provider calls.
- Added permission-bound workspace learning operator override with mandatory future expiration and audit note; an eight-session local replay verified active older selection, exact latest-revision fallback after expiry and clear, exact repin parity, foreign and unretrieved memory isolation, and content-free timeline evidence without external provider calls.
- Added a workspace learning operator surface to the existing action inbox; local HTTP and real Chromium replays verified content-free not-set, active, expired, and cleared state, tenant-checked set and clear mutations, sanitized responses, timeline history, and zero external provider calls.
- Added explicit mission-to-user learning authorization for tenant-free local workspaces and applied approved user decisions and preferences in the stub runtime; a seven-session replay verified sibling and cross-workspace failed-to-passed personalization, exact rollback parity, tenant-bound refusal, and zero external provider calls.
- Added deterministic latest-revision selection for conflicting retrieved local-user decisions; an eight-session replay across two tenant-free workspaces verified selected-only provider exposure, cross-workspace application, exact older fallback after newer revocation, exact baseline restoration after full rollback, and zero external provider calls.
- Added an approved training record contract that requires reviewer pass, operator approval, promotion verification, mission-scoped artifact lineage, sanitized content checks, and deterministic hashes without authorizing external fine-tuning submission.
- Added a deterministic training dataset quality gate with content, lineage, and near-response deduplication, mission-scoped train/validation splitting, leakage checks, and content-free manifests without authorizing dataset export or fine-tuning execution.
- Added a provider-neutral fine-tuning readiness export with train/validation JSONL, Q1 answer-quality baseline binding, reviewer checklist, file digests, and rollback requirements without authorizing provider submission or training execution.
- Added a candidate model evaluation gate that compares fixture or recorded results against the same Q1 case set and thresholds, requires bound evidence, keeps rollout disabled, and returns keep-baseline on regression.
- Added a smoke validation summary and command guard to document the deterministic public-readiness verification baseline without expanding provider, hosted, or production claims.
- Added an external evidence blocker register and smoke guard to keep account, provider, demo URL, pilot feedback, metrics, and hosted deployment blockers explicit.

## v0.1.0 - 2026-06-23

Initial public portfolio release for the local-first Personal AI Agent harness.

Validated boundary:

- Claim: `provider-scoped pilot-ready` for an OpenAI-backed local-first/self-hosted path.
- `productionReadyClaim: false` remains in release evidence.
- The project is not all-provider-complete and is not a hosted SaaS product.
- There is no public hosted demo URL; the current demo is a credential-free recorded local replay and evidence package.

Public release artifact:

- Release: [v0.1.0](https://github.com/sungjin9288/personal-ai-agent/releases/tag/v0.1.0)
- Asset: `personal_ai_agent_portfolio_pack.zip`
- Size and SHA-256 are tracked in the repository root `portfolio_manifest.md` after the ZIP is generated.

Included public surfaces:

- Professional README with scoped portfolio overview, representative demo preview, setup, testing, release evidence, and limitations.
- Credential-free `npm run doctor` diagnostics for local setup, required file/script checks, provider configuration status, and `.env.example` coverage.
- Credential-free `/api/doctor` and operator console local diagnostics summary backed by `npm run smoke:ui-doctor-surface`.
- Credential-free `npm run demo:local` replay path.
- Demo evidence index, preview screenshot, replay log, summary JSON, and browser E2E evidence references.
- `.env.example` and `smoke:env-example` for local provider/runtime configuration onboarding.
- `CONTRIBUTING.md`, fork onboarding guide, `SECURITY.md`, `SUPPORT.md`, and GitHub issue templates.
- `smoke:support-policy` for setup, provider configuration, release evidence, and public issue safety routing.
- Provider smoke CI gates for fallback, attention remediation, provider events, provider overview, target provider operations, release hygiene, and public onboarding checks.
- Manifest-only pilot export package and release artifact hygiene checks.

Verification baseline:

```bash
npm run package:pilot-export
npm run smoke:doctor
npm run smoke:ui-doctor-surface
npm run smoke:changelog
npm run smoke:portfolio-zip
npm run smoke:contributor-onboarding
npm run smoke:env-example
npm run smoke:demo-local
npm run smoke:demo-evidence-index
npm run smoke:readme-portfolio-overview
npm run smoke:portfolio-docs-claim-boundary
npm run smoke:pilot-export-package
npm run smoke:release-artifact-hygiene
```
